from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the saved model pipeline
pipeline = joblib.load('xgb_pipeline_model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user inputs from the form
    hashtags_count = int(request.form['hashtags_count'])
    mentions_count = int(request.form['mentions_count'])
    post_frequency = int(request.form['post_frequency'])
    user_engagement = request.form['user_engagement']
    sentiment_score = request.form['sentiment_score']
    influencers_count = int(request.form['influencers_count'])
    time_of_day = request.form['time_of_day']
    category = request.form['category']

    # Create a DataFrame from user input
    input_data = pd.DataFrame({
        'Hashtags_Count': [hashtags_count],
        'Mentions_Count': [mentions_count],
        'Post_Frequency': [post_frequency],
        'User_Engagement': [user_engagement],
        'Sentiment_Score': [sentiment_score],
        'Influencers_Count': [influencers_count],
        'Time_of_Day': [time_of_day],
        'Category': [category]
    })

    # Make prediction using the loaded model
    prediction = pipeline.predict(input_data)

    # Render the prediction result
    return render_template('result.html', prediction=prediction[0])

if __name__ == "__main__":
    app.run(debug=True)
