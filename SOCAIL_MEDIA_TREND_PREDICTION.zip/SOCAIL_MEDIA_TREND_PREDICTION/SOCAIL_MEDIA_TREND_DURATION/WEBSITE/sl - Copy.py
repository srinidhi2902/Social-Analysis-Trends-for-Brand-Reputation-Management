import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from g4f.client import Client

# Load the saved model pipeline
pipeline = joblib.load('xgb_pipeline_model.pkl')

# Initialize the GPT-4o-mini client
client = Client()

# Custom CSS for a modern, sleek design (Light theme only)
st.markdown("""
    <style>
    .main {
        background-color: #f7f9fc;
        padding: 30px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
    }
    .stButton>button {
        background-color: #007bff;
        color: white;
        border-radius: 8px;
        padding: 12px 24px;
        font-weight: 600;
        transition: background-color 0.3s ease;
    }
    .stButton>button:hover {
        background-color: #0056b3;
    }
    .stTabs {
        background-color: #ffffff;
        border-radius: 12px;
        padding: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.03);
    }
    h1 {
        color: #1a3c6d;
        font-family: 'Segoe UI', sans-serif;
        font-weight: 700;
    }
    h2, h3 {
        color: #2c5282;
        font-family: 'Segoe UI', sans-serif;
        font-weight: 600;
    }
    .stTextInput>label, .stNumberInput>label, .stSelectbox>label {
        font-weight: 600;
        color: #2d3748;
        font-family: 'Segoe UI', sans-serif;
    }
    .stExpander {
        background-color: #fff;
        border-radius: 10px;
        border: 1px solid #e2e8f0;
    }
    .sidebar .sidebar-content {
        background-color: #2d3748;
        color: white;
        border-radius: 10px;
    }
    .stProgress .st-bo {
        background-color: #007bff;
    }
    </style>
""", unsafe_allow_html=True)

# Function to create bar chart
def create_bar_chart(data, x_col, y_col):
    plt.figure(figsize=(12, 6))
    sns.barplot(data=data, x=x_col, y=y_col, palette="coolwarm")
    plt.xticks(rotation=45, ha="right")
    plt.title(f'{y_col} by {x_col}', fontsize=16, pad=20, weight='bold')
    plt.xlabel(x_col, fontsize=12)
    plt.ylabel(y_col, fontsize=12)
    plt.tight_layout()
    return plt

# Function to create pie chart
def create_pie_chart(data, column):
    plt.figure(figsize=(8, 8))
    data[column].value_counts().plot.pie(autopct='%1.1f%%', colors=sns.color_palette("Set2"), startangle=90, textprops={'fontsize': 12})
    plt.title(f'Distribution of {column}', fontsize=16, pad=20, weight='bold')
    plt.ylabel('')
    plt.tight_layout()
    return plt

# Function to generate suggestions using GPT-4o-mini
def generate_suggestions(input_data, prediction):
    prompt = (f"Based on the following input data and predicted engagement duration in days, provide suggestions to improve engagement:\n\n"
              f"Input Data:\n{input_data.to_string()}\n\n"
              f"Predicted Duration: {prediction[0]:.2f} days\n\n"
              f"Suggestions:")
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        web_search=False
    )
    return response.choices[0].message.content

# Function to generate chatbot response
def generate_chatbot_response(user_input):
    prompt = f"User: {user_input}\n\nChatbot:"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        web_search=False
    )
    return response.choices[0].message.content

# Streamlit UI
def main():
    st.title("📊 Social Media Trend Analyzer")
    st.markdown("<p style='color: #718096; font-size: 16px;'>Predict engagement, visualize trends, and get actionable insights.</p>", unsafe_allow_html=True)

    # Sidebar with app info (no theme toggle)
    with st.sidebar:
        st.markdown("<h3 style='color: #edf2f7;'>Settings</h3>", unsafe_allow_html=True)
        st.markdown("<p style='color: #a0aec0;'>Built with ❤️ by xAI</p>", unsafe_allow_html=True)

    # Tabs with icons
    tab1, tab2, tab3 = st.tabs(["🔍 Predict", "📈 Visualize", "💬 Insights"])

    # Prediction Tab
    with tab1:
        st.subheader("Predict Engagement Duration")
        with st.expander("Enter Post Details", expanded=True):
            col1, col2 = st.columns(2)
            with col1:
                hashtags_count = st.number_input("Hashtags Count", min_value=0, step=1, help="Number of hashtags in the post")
                mentions_count = st.number_input("Mentions Count", min_value=0, step=1, help="Number of mentions in the post")
                post_frequency = st.number_input("Post Frequency", min_value=0, step=1, help="Frequency of posts per day")
                user_engagement = st.selectbox("User Engagement", ["Very Low", "Low", "Medium", "High", "Very High"], help="Engagement level")
            with col2:
                sentiment_score = st.selectbox("Sentiment Score", ["Very Negative", "Negative", "Neutral", "Positive", "Very Positive"], help="Post sentiment")
                influencers_count = st.number_input("Influencers Count", min_value=0, step=1, help="Number of influencers involved")
                time_of_day = st.selectbox("Time of Day", ["Morning", "Afternoon", "Evening", "Night"], help="Posting time")
                category = st.selectbox("Category", ["Technology", "Politics", "Sports", "Entertainment", "Health"], help="Post category")

        if st.button("Predict Engagement", key="predict_button"):
            with st.spinner("Analyzing data..."):
                input_data = pd.DataFrame({
                    'Hashtags_Count': [hashtags_count],
                    'Mentions_Count': [mentions_count],
                    'Post_Frequency': [post_frequency],
                    'User_Engagement': [user_engagement],
                    'Sentiment_Score': [sentiment_score],
                    'Influencers_Count': [influencers_count],
                    'Time_of_Day': [time_of_day],
                    'Category': [category]
                })
                prediction = pipeline.predict(input_data)
                st.success(f"Predicted Engagement Duration: **{prediction[0]:.2f} days**")
                suggestions = generate_suggestions(input_data, prediction)
                st.subheader("Actionable Suggestions")
                st.markdown(f"<div style='background-color: #e6fffa; padding: 15px; border-radius: 8px;'>{suggestions}</div>", unsafe_allow_html=True)

    # Visualization Tab
    with tab2:
        st.subheader("Visualize Trends")
        uploaded_file = st.file_uploader("Upload CSV Dataset", type=['csv'], help="Upload a dataset for visualization")
        if uploaded_file:
            df = pd.read_csv(uploaded_file)
            st.write("Dataset Preview:")
            st.dataframe(df.head(), use_container_width=True)
            columns = df.columns.tolist()

            chart_type = st.selectbox("Select Chart Type", ["Bar Chart", "Pie Chart"], help="Choose a visualization type")
            if chart_type == "Bar Chart":
                col1, col2 = st.columns(2)
                with col1:
                    x_col = st.selectbox("X-axis", columns)
                with col2:
                    y_col = st.selectbox("Y-axis", [col for col in columns if col != x_col])
                if st.button("Generate Bar Chart", key="bar_button"):
                    with st.spinner("Creating chart..."):
                        try:
                            fig = create_bar_chart(df, x_col, y_col)
                            st.pyplot(fig)
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
            elif chart_type == "Pie Chart":
                pie_col = st.selectbox("Column for Pie Chart", columns)
                if st.button("Generate Pie Chart", key="pie_button"):
                    with st.spinner("Creating chart..."):
                        try:
                            fig = create_pie_chart(df, pie_col)
                            st.pyplot(fig)
                        except Exception as e:
                            st.error(f"Error: {str(e)}")

    # Chatbot Tab
    with tab3:
        st.subheader("Chat with Insights")
        user_input = st.text_input("Ask a Question:", "", help="Ask anything about social media trends or your data")
        if st.button("Send", key="chat_button"):
            with st.spinner("Generating response..."):
                if user_input:
                    response = generate_chatbot_response(user_input)
                    st.markdown(f"<div style='background-color: #f1f3f5; padding: 15px; border-radius: 8px;'><b>Insights:</b> {response}</div>", unsafe_allow_html=True)

if __name__ == "__main__":
    main()