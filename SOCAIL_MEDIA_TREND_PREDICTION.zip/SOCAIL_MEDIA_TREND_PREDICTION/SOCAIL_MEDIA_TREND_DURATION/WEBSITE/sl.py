import streamlit as st
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from g4f.client import Client

# Load the saved model pipeline
pipeline = joblib.load('xgb_pipeline_model.pkl')

# Initialize the GPT-4o-mini client
client = Client()

# Custom CSS for a bold, dark-themed, futuristic design
st.markdown("""
    <style>
    .main {
        background: linear-gradient(135deg, #0f172a, #1e293b);
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        max-width: 1300px;
        margin: 20px auto;
    }
    .stButton>button {
        background: linear-gradient(90deg, #8b5cf6, #d946ef);
        color: #ffffff;
        border: none;
        border-radius: 10px;
        padding: 14px 30px;
        font-weight: 700;
        font-size: 16px;
        text-transform: uppercase;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }
    .stButton>button:hover {
        background: linear-gradient(90deg, #7c3aed, #c026d3);
        transform: scale(1.05);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }
    .stTabs {
        background-color: #1e293b;
        border-radius: 15px;
        padding: 25px;
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    h1 {
        color: #a78bfa;
        font-family: 'Orbitron', sans-serif;
        font-weight: 700;
        font-size: 40px;
        text-align: center;
        margin-bottom: 15px;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }
    h2, h3 {
        color: #d4d4d8;
        font-family: 'Orbitron', sans-serif;
        font-weight: 600;
    }
    .stTextInput>label, .stNumberInput>label, .stSelectbox>label {
        font-weight: 600;
        color: #e5e7eb;
        font-family: 'Roboto', sans-serif;
        font-size: 14px;
    }
    .stTextInput>div>input, .stNumberInput>div>input, .stSelectbox>div>select {
        background-color: #334155;
        color: #ffffff;
        border-radius: 8px;
        border: 1px solid #475569;
    }
    .stExpander {
        background-color: #1e293b;
        border-radius: 12px;
        border: 1px solid #475569;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .sidebar .sidebar-content {
        background: linear-gradient(135deg, #4c1d95, #7c3aed);
        color: #ffffff;
        border-radius: 15px;
        padding: 25px;
    }
    .stProgress .st-bo {
        background-color: #8b5cf6;
    }
    .stDataFrame {
        background-color: #1e293b;
        border-radius: 10px;
        border: 1px solid #475569;
        padding: 15px;
        color: #d4d4d8;
    }
    .insight-box {
        background-color: #2d3748;
        padding: 20px;
        border-radius: 12px;
        border-left: 6px solid #8b5cf6;
        color: #e5e7eb;
        font-size: 15px;
        line-height: 1.6;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }
    </style>
""", unsafe_allow_html=True)

# Function to create bar chart
def create_bar_chart(data, x_col, y_col):
    plt.figure(figsize=(12, 6))
    sns.barplot(data=data, x=x_col, y=y_col, palette="magma")
    plt.xticks(rotation=45, ha="right", fontsize=12, color='#d4d4d8')
    plt.title(f'{y_col} by {x_col}', fontsize=18, pad=20, weight='bold', color='#a78bfa')
    plt.xlabel(x_col, fontsize=14, color='#e5e7eb')
    plt.ylabel(y_col, fontsize=14, color='#e5e7eb')
    plt.gca().set_facecolor('#1e293b')
    plt.gcf().set_facecolor('#0f172a')
    plt.tight_layout()
    return plt

# Function to create pie chart
def create_pie_chart(data, column):
    plt.figure(figsize=(8, 8))
    data[column].value_counts().plot.pie(autopct='%1.1f%%', colors=sns.color_palette("flare"), startangle=90, textprops={'fontsize': 12, 'color': '#e5e7eb'})
    plt.title(f'Distribution of {column}', fontsize=18, pad=20, weight='bold', color='#a78bfa')
    plt.ylabel('')
    plt.gca().set_facecolor('#1e293b')
    plt.gcf().set_facecolor('#0f172a')
    plt.tight_layout()
    return plt

# Function to generate suggestions using GPT-4o-mini
def generate_suggestions(input_data, prediction):
    prompt = (f"Based on the following input data and predicted engagement duration in days, provide concise, actionable suggestions to improve engagement:\n\n"
              f"Input Data:\n{input_data.to_string()}\n\n"
              f"Predicted Duration: {prediction[0]:.2f} days\n\n"
              f"Suggestions:")
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        web_search=False
    )
    return response.choices[0].message.content

# Function to generate chatbot response
def generate_chatbot_response(user_input):
    prompt = f"User: {user_input}\n\nChatbot: Provide a concise, helpful response related to social media trends or data analysis."
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        web_search=False
    )
    return response.choices[0].message.content

# Streamlit UI
def main():
    st.title("🌌 Social Media Trend Analyzer")
    st.markdown("<p style='color: #9ca3af; font-size: 16px; text-align: center; margin-bottom: 30px;'>Dive into the future of engagement analytics.</p>", unsafe_allow_html=True)

    # Sidebar with app info and branding
    with st.sidebar:
        st.markdown("<h3 style='color: #e9d5ff;'>Analyzer Hub</h3>", unsafe_allow_html=True)
        st.markdown("<p style='color: #c4b5fd;'>Powered by xAI<br>Futuristic Insights<br>March 2025</p>", unsafe_allow_html=True)
        st.image("https://via.placeholder.com/150x50.png?text=xAI+Logo", use_column_width=True)

    # Tabs with icons and bold styling
    tab1, tab2, tab3 = st.tabs(["🔮 Predict", "📊 Visualize", "💡 Insights"])

    # Prediction Tab
    with tab1:
        st.subheader("Predict Engagement Duration")
        with st.expander("Input Post Data", expanded=True):
            col1, col2 = st.columns(2, gap="medium")
            with col1:
                hashtags_count = st.number_input("Hashtags Count", min_value=0, step=1, help="Number of hashtags")
                mentions_count = st.number_input("Mentions Count", min_value=0, step=1, help="Number of mentions")
                post_frequency = st.number_input("Post Frequency", min_value=0, step=1, help="Posts per day")
                user_engagement = st.selectbox("User Engagement", ["Very Low", "Low", "Medium", "High", "Very High"], help="Engagement level")
            with col2:
                sentiment_score = st.selectbox("Sentiment Score", ["Very Negative", "Negative", "Neutral", "Positive", "Very Positive"], help="Post sentiment")
                influencers_count = st.number_input("Influencers Count", min_value=0, step=1, help="Number of influencers")
                time_of_day = st.selectbox("Time of Day", ["Morning", "Afternoon", "Evening", "Night"], help="Posting time")
                category = st.selectbox("Category", ["Technology", "Politics", "Sports", "Entertainment", "Health"], help="Post category")

        if st.button("Predict Now", key="predict_button"):
            with st.spinner("Processing..."):
                input_data = pd.DataFrame({
                    'Hashtags_Count': [hashtags_count],
                    'Mentions_Count': [mentions_count],
                    'Post_Frequency': [post_frequency],
                    'User_Engagement': [user_engagement],
                    'Sentiment_Score': [sentiment_score],
                    'Influencers_Count': [influencers_count],
                    'Time_of_Day': [time_of_day],
                    'Category': [category]
                })
                prediction = pipeline.predict(input_data)
                st.success(f"Predicted Duration: **{prediction[0]:.2f} days**")
                suggestions = generate_suggestions(input_data, prediction)
                st.subheader("Next Steps")
                st.markdown(f"<div class='insight-box'>{suggestions}</div>", unsafe_allow_html=True)

    # Visualization Tab
    with tab2:
        st.subheader("Visualize Trends")
        uploaded_file = st.file_uploader("Upload CSV Dataset", type=['csv'], help="Upload your data")
        if uploaded_file:
            df = pd.read_csv(uploaded_file)
            st.write("Data Snapshot:")
            st.dataframe(df.head(), use_container_width=True)
            columns = df.columns.tolist()

            chart_type = st.selectbox("Chart Type", ["Bar Chart", "Pie Chart"], help="Select visualization")
            col1, col2 = st.columns(2)
            if chart_type == "Bar Chart":
                with col1:
                    x_col = st.selectbox("X-axis", columns)
                with col2:
                    y_col = st.selectbox("Y-axis", [col for col in columns if col != x_col])
                if st.button("Render Bar Chart", key="bar_button"):
                    with st.spinner("Generating..."):
                        try:
                            fig = create_bar_chart(df, x_col, y_col)
                            st.pyplot(fig)
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
            elif chart_type == "Pie Chart":
                with col1:
                    pie_col = st.selectbox("Column for Pie Chart", columns)
                if st.button("Render Pie Chart", key="pie_button"):
                    with st.spinner("Generating..."):
                        try:
                            fig = create_pie_chart(df, pie_col)
                            st.pyplot(fig)
                        except Exception as e:
                            st.error(f"Error: {str(e)}")

    # Chatbot Tab
    with tab3:
        st.subheader("Ask for Insights")
        user_input = st.text_input("Your Question:", "", help="Ask about trends or data", placeholder="e.g., What's trending now?")
        if st.button("Analyze", key="chat_button"):
            with st.spinner("Thinking..."):
                if user_input:
                    response = generate_chatbot_response(user_input)
                    st.markdown(f"<div class='insight-box'><b>Response:</b> {response}</div>", unsafe_allow_html=True)

if __name__ == "__main__":
    main()